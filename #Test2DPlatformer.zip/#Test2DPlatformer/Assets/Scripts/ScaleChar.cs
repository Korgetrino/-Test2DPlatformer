﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScaleChar : MonoBehaviour
{
    public GameObject go; // Объект, размер которого будем менять (задается в инспекторе)
    private float timer = 10.0f; // Ставим таймер на 10 секунд
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        timer -= 1.0f * Time.deltaTime; // Отнимаем от таймера 1 в секунду
        if (timer <= 0.0f)
        { // Если таймер пришел к нулю
            go.transform.localScale = new Vector3(Random.Range(2.0f, 10.0f), Random.Range(2.0f, 10.0f), Random.Range(2.0f, 10.0f)); // Меняем размер объекта
            timer = 10.0f; // Снова ставим таймер на 10 секунд 
        }
    }
}
