﻿using UnityEngine;
using System.Collections;

public class LivesBar : MonoBehaviour
{
    // Массив элементов
    private Transform[] hearts = new Transform[3];

    private Character character;

   
    // Метод записывания элементов LivesBar
    private void Awake()
    {
        character = FindObjectOfType<Character>();

        for (int i = 0; i < hearts.Length; i++)
        {
            hearts[i] = transform.GetChild(i);
            Debug.Log(hearts[i]);
        }
    }

    // Метод обновления текущего HP
    public void Refresh()
    {
        // Количетсво активных ячеек здоровья
        for (int i = 0; i < hearts.Length; i++)
        {
            if (i < character.Lives) hearts[i].gameObject.SetActive(true);
            else hearts[i].gameObject.SetActive(false);
        }
    }
}
