﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TerrainGenerator : MonoBehaviour
{
    public GameObject Cell;
    public Transform Zero;
    public int Height = 1, Width = 1;

    public void Start()
    {
        Generate();
    }

    public void Generate()
    {
        for(int x = 0; x < Width; x ++)
        {
            if(x % 2 == 0)
            {
                Height += Random.Range(-1, 2);
            }

            for(int y = Height; y > 0; y --)
            {
                var cell = Instantiate(Cell, Zero);
                cell.transform.localPosition = new Vector3(x, y, 0);
            }
        }
    }
}