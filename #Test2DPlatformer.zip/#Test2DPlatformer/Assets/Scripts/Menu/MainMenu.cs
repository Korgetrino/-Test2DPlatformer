﻿using UnityEngine;
using System.Collections;

public class MainMenu : MonoBehaviour {

	public int level;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	public void startGame()
	{
		Application.LoadLevel (level);
	}
	public void exitGame()
	{
		Application.Quit ();
	}
}