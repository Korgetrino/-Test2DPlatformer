﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class Character : Unit
{
    public GameObject scaletransform;
    public GameObject Death;
    public GameObject Paused;
    float x = 0.5F;
    float y = 0.5F;
    float z = 0.5F;
    [SerializeField]
    private int weight = 1;

    [SerializeField]
    private int lives = 3; // Здоровье

    void Start()
    {
        Death.SetActive(false);
    }

    // Свойство LivesBar
    public int Lives
    {
        get { return lives; }
        set
        {
            if (value < 3) lives = value;
            livesBar.Refresh();

            if(lives < 1)
            {
                Death.SetActive(true);
                Time.timeScale = 0;
            }
        }
    }
    private LivesBar livesBar;

    [SerializeField]
    private float speed = 3.0F; // Скорость перемещения
    [SerializeField]
    private float jumpForce = 15.0F; // Высота прыжка

    private bool isGrounded = false;


    private CharState State
    {
        get { return (CharState)animator.GetInteger("State"); }
        set { animator.SetInteger("State", (int)value); }
    }

    new private Rigidbody2D rigidbody;
    private Animator animator;
    private SpriteRenderer sprite;

    private void Awake()
    {
        livesBar = FindObjectOfType<LivesBar>();
        rigidbody = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
        sprite = GetComponentInChildren<SpriteRenderer>();
    }

    private void FixedUpdate()
    {
        CheckGround();
    }


    private void Update()
    {
        if (isGrounded) State = CharState.Idle;

        if (Input.GetButton("Horizontal")) Run();
        if (isGrounded && Input.GetButtonDown("Jump")) Jump();

        /*System.Random rnd = new System.Random();
        int i = 1 + rnd.Next(5);*/

        switch (weight)
        {
            case 1:
                x = 0.5F;
                y = 0.5F;
                z = 0.5F;
                break;
            case 2:
                x = 0.6F;
                y = 0.6F;
                z = 0.6F;
                break;
            case 3:
                x = 0.7F;
                y = 0.7F;
                z = 0.7F;
                break;
            case 4:
                x = 0.8F;
                y = 0.8F;
                z = 0.8F;
                break;
            case 5:
                x = 1.0F;
                y = 1.0F;
                z = 1.0F;
                break;
        }
        scaletransform.transform.localScale = new Vector3(x, y, z);
    }

    private void Run()
    {
        Vector3 direction = transform.right * Input.GetAxis("Horizontal");

        transform.position = Vector3.MoveTowards(transform.position, transform.position + direction, speed * Time.deltaTime);

        sprite.flipX = direction.x < 0.0F;

        if (isGrounded) State = CharState.Run;
    }

    private void Jump()
    {
        rigidbody.AddForce(transform.up * jumpForce, ForceMode2D.Impulse);
    }

    public override void ReceiveDamage()
    {
        Lives--;

        rigidbody.velocity = Vector3.zero;
        rigidbody.AddForce(transform.up * 8.0F, ForceMode2D.Impulse);

        Debug.Log(lives);
    }

    private void CheckGround()
    {
        Collider2D[] colliders = Physics2D.OverlapCircleAll(transform.position, 0.3F);

        isGrounded = colliders.Length > 1;

        if (!isGrounded) State = CharState.Jump;
    }


    public enum CharState
    {
        Idle,
        Run,
        Jump
    }
}